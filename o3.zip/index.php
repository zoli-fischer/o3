<?php 
	header("location: admin/index.php")
?>