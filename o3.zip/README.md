# O3 Engine for PHP

O3 Engine makes the creation and maintain of PHP projects easyer, faster and better. 

O3 Engine includes a set of classes and functions that are basic for every project, the developers don't need to waste time on collecting them.

> Current version: v1.0.0e

## Requirements

PHP 5.3.x (http://php.net)

## Documentation

[Click here for documentation](https://github.com/zoli-fischer/o3/wiki)

## Download

[Click here for download](https://github.com/zoli-fischer/o3/raw/master/o3.zip)

## License

o3-video is licensed under the MIT License. [View the license file](LICENSE)