# o3-engine v1.0.0b - Engine for PHP

> O3 Engine for PHP

## Requirements

PHP 5.3.x (http://php.net)

## Download

[Click here for download](https://github.com/zoli-fischer/o3-video/raw/master/o3-video.zip)

## License

o3-video is licensed under the MIT License. [View the license file](LICENSE)

Copyright 2014 Zoltan L. Fischer