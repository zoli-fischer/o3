<?php


/*Use o3.config.php in the site root folder*/

?>